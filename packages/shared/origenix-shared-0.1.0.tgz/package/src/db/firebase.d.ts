export { db, collections, auth } from "@origenix/database";
